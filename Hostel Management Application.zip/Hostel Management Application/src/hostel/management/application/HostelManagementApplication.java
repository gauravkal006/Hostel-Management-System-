
package hostel.management.application;

public class HostelManagementApplication {

   
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
